package com.silverbarsmarketplace.LiveOrderBoard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LiveOrderBoardApplicationTests {

	@Test
	void contextLoads() {
	}

}
